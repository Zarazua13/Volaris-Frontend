import * as React from 'react'
import { CaretSortIcon, CheckIcon } from '@radix-ui/react-icons'

import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem
} from '@/components/ui/command'
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover'
import { ScrollArea } from './ui/scroll-area'

interface LocationCombobox {
  label: string
  value: string
}

interface Props {
 locations: LocationCombobox[] 
}

export function LocationsCombobox ({ locations = [] }:Props) {
  const [open, setOpen] = React.useState(false)
  const [value, setValue] = React.useState('')

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant='outline'
          role='combobox'
          aria-expanded={open}
          className='w-[200px] justify-between'
        >
          {value
            ? locations.find(location => location.value === value)?.label
            : 'Buscar ubicación...'}
          <CaretSortIcon className='ml-2 h-4 w-4 shrink-0 opacity-50' />
        </Button>
      </PopoverTrigger>
      <PopoverContent className='w-[200px] p-0'>
        <Command>
          <CommandInput placeholder='Buscar ubicación...' className='h-9' />
          <ScrollArea className='h-96'>
            <CommandEmpty>No framework found.</CommandEmpty>
            <CommandGroup>
              {locations.map(location => (
                <CommandItem
                  key={location.value}
                  value={location.value}
                  onSelect={() => {
                    setValue(value === location.value ? '' : location.value)
                    setOpen(false)
                  }}
                >
                  {location.label}
                  <CheckIcon
                    className={cn(
                      'ml-auto h-4 w-4',
                      value === location.value ? 'opacity-100' : 'opacity-0'
                    )}
                  />
                </CommandItem>
              ))}
            </CommandGroup>
          </ScrollArea>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
