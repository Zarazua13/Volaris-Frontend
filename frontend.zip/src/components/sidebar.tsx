import { NavLink, useNavigate } from 'react-router-dom'

import { useMsal } from '@azure/msal-react'
import { Users, FilePlus, UserSquare2, PlaneTakeoff, Settings } from 'lucide-react'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'

import { clearToken } from '@/lib/storage'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { ModeToggle } from './mode-toggle'

const items = [
  {
    title: 'Responsivas',
    to: '/responsives',
    icon: <FilePlus />
  },
  {
    title: 'Empleados',
    to: '/employees',
    icon: <UserSquare2 />
  },
  {
    title: 'Usuarios',
    to: '/users',
    icon: <Users />
  },
  {
    title: 'Configuración',
    to: '/settings',
    icon: <Settings />
  }
]

const Sidebar = () => {
  const { accounts, instance } = useMsal()
  const navigate = useNavigate()

  const logOut = async () => {
    await instance.logoutPopup({
      postLogoutRedirectUri: '/'
    })
    clearToken()
    navigate('/login')
  }

  if (accounts.length > 0) {
    return (
      <aside className='w-[248px] fixed border border-r-1 h-full py-[24px] px-[16px] flex flex-col justify-between'>
        <div className='w-[216px]'>
          <div className='mb-10 flex items-center rounded-lg px-3 py-2 text-slate-900 dark:text-white'>
            <PlaneTakeoff />
            <span className='ml-3 text-base font-semibold'>Volaris</span>
          </div>
          <ul>
            {items.map(item => (
              <li key={item.to}>
                <NavLink
                  className={({ isActive }) =>
                    `flex h-[36px] mb-2 [&>svg]:w-[20px] [&>svg]:mr-5 rounded-lg hover:bg-accent ${
                      isActive ? 'bg-accent' : ''
                    } items-center px-[12px] py-[8px]`
                  }
                  to={item.to}
                >
                  {item.icon}
                  <span>{item.title}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <ModeToggle />
          <DropdownMenu>
            <DropdownMenuTrigger className='w-full text-left p-2 rounded-lg hover:bg-accent flex justify-between items-center'>
              <Avatar>
                <AvatarImage src='' />
                <AvatarFallback>
                  {accounts[0].name?.split(' ').reduce((prev, curr) => prev + curr[0],'')}
                </AvatarFallback>
              </Avatar>
              <span>{accounts[0].name}</span>
              <span className='pb-3'>...</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent side='right'>
              <DropdownMenuLabel>
                Mi Cuenta
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logOut}>
                Cerrar sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>
    )
  }
}

export default Sidebar
