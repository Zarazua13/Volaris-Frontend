import Layout from "@/components/layout"
import { useIsAuthenticated } from "@azure/msal-react"
import { Outlet, useNavigate } from "react-router-dom"

const Dashboard = () => {
  const isAuthenticated = useIsAuthenticated()
  const navigate = useNavigate()

  if(!isAuthenticated)  navigate('/login')

  return (
    <Layout>
      <Outlet />
    </Layout>
  )
}

export default Dashboard