import { useEffect } from 'react'

// import { getEmployees } from '@/lib/request'

const Employees = () => {
  // useEffect(() => {
  //   getEmployees()
  //     .then(res => console.log(res))
  //     .catch(err => console.log(err))
  // }, [])

  return <div>Employees</div>
}

export default Employees
