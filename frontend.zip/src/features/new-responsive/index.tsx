import { useEffect, useReducer } from 'react'

import { debounce } from 'lodash'
import { RegisterOptions, SubmitHandler, useForm } from 'react-hook-form'

import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'

import { reducer } from './reducer'
import {
  GetAssignerAction,
  GetLocationsAction,
  GetReceiverAction,
  INITIAL_STATE,
  SaveResponsiveAction
} from './actions'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import TitlePage from '@/components/title-page'
import { Eye, Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Icons } from '@/components/ui/icons'

import { getEmployee } from '@/lib/baas/employees'
import { postResponsive } from '@/lib/baas/responsives'
import { getLocations } from '@/lib/baas/locations'
import { LocationsCombobox } from '@/components/locations-combobox'
import { Location } from '@/interfaces/locations'

interface Form {
  label: string
  name: 'device' | 'brand' | 'serialNumber' | 'model' | 'description'
  id: string
  htmlFor: string
  placeholder: string
  register: RegisterOptions
}

const deviceForm: Form[] = [
  {
    label: 'Equipo',
    name: 'device',
    id: 'device',
    htmlFor: 'device',
    placeholder: 'Laptop',
    register: {
      required: true
    }
  },
  {
    label: 'Marca',
    name: 'brand',
    id: 'brand',
    htmlFor: 'brand',
    placeholder: 'HP',
    register: {
      required: true
    }
  },
  {
    label: 'Numero de serie',
    name: 'serialNumber',
    id: 'serialNumber',
    htmlFor: 'serialNumber',
    placeholder: '1234567',
    register: {
      required: true
    }
  },
  {
    label: 'Modelo',
    name: 'model',
    id: 'model',
    htmlFor: 'model',
    placeholder: 'ZBook',
    register: {
      required: true
    }
  },
  {
    label: 'Descripción',
    name: 'description',
    id: 'description',
    htmlFor: 'description',
    placeholder: 'Equipo de trabajo',
    register: {
      required: true
    }
  }
]

type FormValues = {
  device: string
  brand: string
  serialNumber: string
  model: string
  description: string
}

const NewResponsive = () => {
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE)
  const {
    register,
    formState: { isValid },
    handleSubmit
  } = useForm({
    defaultValues: {
      device: '',
      brand: '',
      serialNumber: '',
      model: '',
      description: ''
    },
    mode: 'onChange'
  })
  const assignerState = state.assigner
  const receiverState = state.receiver
  const locationsState = state.location
  const assigner = assignerState.data
  const receiver = receiverState.data
  const locations = locationsState.data

  useEffect(() => {
    dispatch({
      type: GetLocationsAction.GET_LOCATIONS_REQUEST
    })
    getLocations<Location>()
      .then((res) => {
        dispatch({
          type: GetLocationsAction.GET_LOCATIONS_SUCCESS,
          payload: res!.map(location => ({ label: location.name, value: location.id }))
        })
      })
      .catch(err => {
        dispatch({
          type: GetLocationsAction.GET_LOCATIONS_ERROR,
          payload: err
        })
      })
  }, [])

  const searchAssigner = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      dispatch({
        type: GetAssignerAction.GET_ASSIGNER_REQUEST
      })
      const employee = await getEmployee(event.target.value)
      dispatch({
        type: GetAssignerAction.GET_ASSIGNER_SUCCESS,
        payload: employee
      })
    } catch (e) {
      dispatch({
        type: GetAssignerAction.GET_ASSIGNER_ERROR,
        payload: e
      })
    }
  }

  const searchReceiver = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      dispatch({
        type: GetReceiverAction.GET_RECEIVER_REQUEST
      })
      const employee = await getEmployee(event.target.value)
      dispatch({
        type: GetReceiverAction.GET_RECEIVER_SUCCESS,
        payload: employee
      })
    } catch (e) {
      dispatch({
        type: GetReceiverAction.GET_RECEIVER_ERROR,
        payload: e
      })
    }
  }

  const debouncedSearchAssigner = debounce(searchAssigner, 1000)

  const debouncedSearchReceiver = debounce(searchReceiver, 1000)

  const onSubmit: SubmitHandler<FormValues> = async values => {
    try {
      dispatch({
        type: SaveResponsiveAction.SAVE_RESPONSIVE_REQUEST
      })
      const res = await postResponsive({
        ...values,
        assigner: assigner.id,
        receiver: receiver.id
      })
      console.log(res)
      dispatch({
        type: SaveResponsiveAction.SAVE_RESPONSIVE_SUCCESS
      })
    } catch (e) {
      dispatch({
        type: SaveResponsiveAction.SAVE_RESPONSIVE_ERROR,
        payload: e
      })
    }
  }

  console.log({ receiver, assigner, locations })

  return (
    <>
      <TitlePage title='Crear nueva responsiva' />
      <div className='container pb-32'>
        <div className='my-5 flex justify-center'>
          <div className='flex flex-col'>
            <Label className='mb-2'>Ubicación</Label>
            <LocationsCombobox locations={locations || []} />
          </div>
        </div>

        {/* ENTREGA */}

        <Card className='mt-5'>
          <CardHeader>
            <h1 className='text-2xl'>Entrega</h1>
            <span className='text-white/40'>
              Selecciona al empleado que entrega el equipo
            </span>
          </CardHeader>
          <CardContent>
            <div className='grid w-full mt-5 items-center gap-4'>
              <div className='flex flex-col space-y-2 px-2'>
                <Label htmlFor='assigner-employee-number'># de empleado</Label>
                <div className='relative'>
                  <Input
                    id='assigner-employee-number'
                    onChange={debouncedSearchAssigner}
                  />
                  {assignerState.loading && (
                    <Icons.spinner className='mr-2 h-4 w-4 absolute stroke-teal-500 top-3 left-3 animate-spin' />
                  )}
                </div>
              </div>
              {assigner && (
                <>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='assigner-name'>Nombre</Label>
                    <Input id='assigner-name' disabled value={assigner.name} />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='assigner-role'>Puesto</Label>
                    <Input
                      id='assigner-role'
                      disabled
                      value={assigner.position.name}
                    />
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* RECIBE */}
        <Card className='mt-5'>
          <CardHeader>
            <h1 className='text-2xl'>Recibe</h1>
            <span className='text-white/40'>
              Selecciona al empleado que recibe el equipo
            </span>
          </CardHeader>
          <CardContent>
            <div className='grid w-full mt-5 items-center gap-4'>
              <div className='flex flex-col space-y-2 px-2'>
                <Label htmlFor='target-employee-number'># de empleado</Label>
                <div className='relative'>
                  <Input
                    id='target-employee-number'
                    onChange={debouncedSearchReceiver}
                  />
                  {receiverState.loading && (
                    <Icons.spinner className='mr-2 h-4 w-4 absolute stroke-teal-500 top-3 left-3 animate-spin' />
                  )}
                </div>
              </div>
              {receiver && (
                <>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-name'>Nombre</Label>
                    <Input id='target-name' value={receiver.name} disabled />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-role'>Puesto</Label>
                    <Input
                      id='target-role'
                      disabled
                      value={receiver.position.name}
                    />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-email'>Correo electrónico</Label>
                    <Input id='target-email' disabled value={receiver.email} />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-boss-name'>
                      Nombre del jefe inmediato
                    </Label>
                    <Input
                      id='target-boss-name'
                      disabled
                      value={receiver.boss.name}
                    />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-boss-employee-number'>
                      # de empleado del jefe inmediato
                    </Label>
                    <Input
                      id='target-boss-employee-number'
                      disabled
                      value={receiver.boss.employeeNumber}
                    />
                  </div>
                  <div className='flex flex-col space-y-2 px-2'>
                    <Label htmlFor='target-boss-role'>
                      Puesto del jefe inmediato
                    </Label>
                    <Input
                      id='target-boss-role'
                      disabled
                      value={receiver.boss.position.name}
                    />
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* CARACTERISTICAS */}

        <form onSubmit={handleSubmit(onSubmit)}>
          <Card className='mt-5'>
            <CardHeader>
              <h1 className='text-2xl'>Caracteristicas de la herramienta</h1>
              <span className='text-white/40'>
                Describe el equipo que se esta entregando/recibiendo
              </span>
            </CardHeader>
            <CardContent>
              <div className='grid w-full mt-5 items-center gap-4'></div>
              <div className='grid w-full items-center gap-4'>
                {deviceForm.map(input => {
                  return (
                    <div className='flex flex-col space-y-2 px-2'>
                      <Label htmlFor={input.htmlFor}>{input.label}</Label>
                      <Input
                        {...register(input.name, input.register)}
                        id={input.id}
                        placeholder={input.placeholder}
                      />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <div className='my-5 flex justify-between mx-auto max-w-sm'>
            <Button type='button' className='mr-3'>
              <Eye />
              Vista previa
            </Button>
            <Button
              type='submit'
              disabled={
                !assigner ||
                !receiver ||
                !isValid ||
                state.saveResponsive.loading
              }
            >
              {state.saveResponsive.loading && (
                <Icons.spinner className='mr-2 h-4 w-4 animate-spin' />
              )}
              <Save />
              Guardar
            </Button>
          </div>
        </form>
      </div>
    </>
  )
}

export default NewResponsive
