import { useEffect, useState } from 'react'

import { Plus } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'

import { getResponsives } from '@/lib/baas/responsives'
import { Responsive } from '@/interfaces/responsive'
import { DataTableDemo } from './table'

const Responsives = () => {
  const navigate = useNavigate()
  const [responsives, setResponsives] = useState<Responsive[]>([])

  useEffect(() => {
    getResponsives<Responsive>()
      .then(res => {
        setResponsives(res)
      })
      .catch(err => {
        console.log(err)
      })
  }, [])

  return (
    <div className='w-full'>
      <div className='flex justify-between'>
        <p className='text-2xl'>Responsivas</p>
        <Button onClick={() => navigate('/new-responsive')}>
          <Plus className='mr-2' />
          Nueva responsiva
        </Button>
      </div>
      <Separator className='my-5' />
      <DataTableDemo responsives={responsives} />
    </div>
  )
}

export default Responsives
