import { Location } from "@/interfaces/locations"
import { Position } from "@/interfaces/position"

export interface Employee {
  id: string
  name: string
  employeeNumber: string
  email: string
  position: Position
  location: Location
  boss: Boss
}


export interface Boss {
  id: string
  name: string
  email: string
  employee_number: string
  boss_id: string
  position_id: number
  location_id: number
}
