export interface Location {
  name: string
  id: number
}