import { Employee } from "@/interfaces/employee"

export interface Responsive {
  id: string
  serial_number: string
  brand: string
  model: string
  type: string
  comment: string
  is_signed: boolean
  created_at: string
  assigner: Employee
  approver: Employee
  receiver: Employee
}