import { request } from '@/lib/request'

import { getToken } from '../storage'
import { Employee } from '@/interfaces/employee'

const BASE_URL = import.meta.env.VITE_API_BASE_URL

export const getResponsive = (responsiveId: number | string) => {
  return request(`${BASE_URL}/api/responsives/${responsiveId}`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${getToken()}`
    }
  }) as Promise<Employee>
}

export function getResponsives<T>(): Promise<T[]> {
  return request(BASE_URL + '/api/responsives', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${getToken()}`
    }
  }) as Promise<T[]>
}

export const postResponsive = responsive =>
  request(BASE_URL + '/api/responsives', {
    method: 'POST',
    data: responsive,
    headers: {
      Authorization: `Bearer ${getToken()}`
    }
  })
