import React from 'react'
import ReactDOM from 'react-dom/client'

import { MsalProvider } from '@azure/msal-react'
import { BrowserRouter } from 'react-router-dom'

import App from './app'
import { msalIstance } from './lib/msal'
import { ThemeProvider } from './components/theme-provider'

import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <MsalProvider instance={msalIstance}>
      <BrowserRouter>
        <ThemeProvider defaultTheme='dark' storageKey='vite-ui-theme'>
          <App />
        </ThemeProvider>
      </BrowserRouter>
    </MsalProvider>
  </React.StrictMode>
)
